const express = require('express');
const router = express.Router();

/* GET home page */
router.get('/', function (req, res) {
  // Temporary text so we know the route works
  res.send('Travlr Getaways home route is working');
});

module.exports = router;
