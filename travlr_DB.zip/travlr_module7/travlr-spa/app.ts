import { Component, OnInit } from '@angular/core';
import { TripsDataService } from './trips-data.service';
import { Trip } from './trip';

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class AppComponent implements OnInit {

  title = 'Travlr Admin Trips';
  trips: Trip[] = [];
  loading = false;
  errorMessage = '';

  constructor(private tripsService: TripsDataService) {}

  ngOnInit() {
    this.loading = true;
    this.tripsService.getTrips().subscribe({
      next: data => {
        this.trips = data;
        this.loading = false;
      },
      error: err => {
        console.error(err);
        this.errorMessage = 'Could not load trips';
        this.loading = false;
      }
    });
  }
}
