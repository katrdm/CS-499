// src/app/trip.ts
export interface Trip {
  _id?: string;
  code: string;
  name: string;
  length: number;
  start: string;        // ISO date string
  resort: string;
  price: number;
  currency: string;
}
