// src/app/app.ts
import { Component, OnInit } from '@angular/core';
import { NgIf, NgFor, DatePipe, CurrencyPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TripsDataService } from './trips-data.service';
import { Trip } from './trip';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [NgIf, NgFor, FormsModule, DatePipe, CurrencyPipe],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class AppComponent implements OnInit {
  title = 'Travlr Admin Trips';

  trips: Trip[] = [];
  loading = false;
  errorMessage = '';
  isEditing = false;
  currentTrip: Trip | null = null;

  constructor(private tripsService: TripsDataService) {}

  ngOnInit(): void {
    this.loadTrips();
  }

  loadTrips(): void {
    this.loading = true;
    this.errorMessage = '';
    this.tripsService.getTrips().subscribe({
      next: trips => {
        this.trips = trips;
        this.loading = false;
      },
      error: err => {
        console.error(err);
        this.errorMessage = 'Could not load trips.';
        this.loading = false;
      }
    });
  }

  startEdit(trip?: Trip): void {
    this.isEditing = true;

    if (trip) {
      // editing an existing trip – clone it
      this.currentTrip = { ...trip };
    } else {
      // adding a new trip
      this.currentTrip = {
        code: '',
        name: '',
        length: 1,
        start: new Date().toISOString(),
        resort: '',
        price: 0,
        currency: 'USD'
      };
    }
  }

  cancelEdit(): void {
    this.isEditing = false;
    this.currentTrip = null;
  }

  saveTrip(): void {
    if (!this.currentTrip) return;

    const isNew = !this.currentTrip._id;
    const request$ = isNew
      ? this.tripsService.addTrip(this.currentTrip)
      : this.tripsService.updateTrip(this.currentTrip);

    request$.subscribe({
      next: () => {
        this.cancelEdit();
        this.loadTrips();
      },
      error: err => {
        console.error(err);
        this.errorMessage = 'Could not save trip.';
      }
    });
  }

  deleteTrip(trip: Trip): void {
    if (!trip._id) return;
    if (!confirm(`Delete trip "${trip.name}"?`)) return;

    this.tripsService.deleteTrip(trip._id).subscribe({
      next: () => this.loadTrips(),
      error: err => {
        console.error(err);
        this.errorMessage = 'Could not delete trip.';
      }
    });
  }
}
