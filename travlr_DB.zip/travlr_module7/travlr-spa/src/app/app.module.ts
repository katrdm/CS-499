// src/app/app.module.ts
import { NgModule } from '@angular/core';

@NgModule({})
export class AppModule {}
