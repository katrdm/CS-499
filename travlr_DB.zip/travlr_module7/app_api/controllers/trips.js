const mongoose = require('mongoose');

// IMPORTANT:
// This MUST match the model name in app_api/models/trips.js
const Trip = mongoose.model('trips');

// Whitelist fields to prevent mass assignment / unsafe writes
const sanitizeTripPayload = (body) => {
  const b = body || {};
  const payload = {
    code: b.code != null ? String(b.code).trim().toUpperCase() : undefined,
    name: b.name != null ? String(b.name).trim() : undefined,
    resort: b.resort != null ? String(b.resort).trim() : undefined,
    length: b.length != null ? Number(b.length) : undefined,
    start: b.start != null ? new Date(b.start) : undefined,
    price: b.price != null ? Number(b.price) : undefined,
    currency: b.currency != null ? String(b.currency).trim().toUpperCase() : undefined,
    description: b.description != null ? String(b.description).trim() : undefined,
    image: b.image != null ? String(b.image).trim() : undefined
  };

  // Remove undefined keys (so updates don't overwrite with undefined)
  Object.keys(payload).forEach(k => payload[k] === undefined && delete payload[k]);
  return payload;
};

// ======================================
// GET /api/trips (Public)
// ======================================
const tripsList = async (req, res) => {
  try {
    // Query optimization: select only needed fields (exclude __v)
    const trips = await Trip.find().select('-__v').lean().exec();
    return res.status(200).json(trips);
  } catch (err) {
    return res.status(500).json({ message: 'Error retrieving trips', error: err.message });
  }
};

// ======================================
// GET /api/trips/:tripCode (Public)
// ======================================
const tripsFindByCode = async (req, res) => {
  try {
    const code = String(req.params.tripCode || '').trim().toUpperCase();
    const trip = await Trip.findOne({ code }).select('-__v').lean().exec();

    if (!trip) return res.status(404).json({ message: 'Trip not found' });
    return res.status(200).json(trip);
  } catch (err) {
    return res.status(500).json({ message: 'Error retrieving trip', error: err.message });
  }
};

// ======================================
// POST /api/trips (Protected – admin)
// ======================================
const tripsAddTrip = async (req, res) => {
  try {
    const payload = sanitizeTripPayload(req.body);

    // Basic required checks (extra layer beyond schema)
    if (!payload.code || !payload.name || !payload.resort) {
      return res.status(400).json({ message: 'code, name, and resort are required' });
    }

    const trip = await Trip.create(payload); // schema validation runs here
    return res.status(201).json(trip);
  } catch (err) {
    // Duplicate key error => unique constraint on code
    if (err && err.code === 11000) {
      return res.status(409).json({ message: 'Trip code must be unique' });
    }
    return res.status(400).json({ message: 'Error creating trip', error: err.message });
  }
};

// ======================================
// PUT /api/trips/:tripCode (Protected – admin)
// ======================================
const tripsUpdateTrip = async (req, res) => {
  try {
    const code = String(req.params.tripCode || '').trim().toUpperCase();
    const payload = sanitizeTripPayload(req.body);

    // Prevent changing code via update endpoint (optional integrity control)
    if (payload.code) delete payload.code;

    const trip = await Trip.findOneAndUpdate(
      { code },
      payload,
      { new: true, runValidators: true }
    ).exec();

    if (!trip) return res.status(404).json({ message: 'Trip not found' });
    return res.status(200).json(trip);
  } catch (err) {
    return res.status(400).json({ message: 'Error updating trip', error: err.message });
  }
};

// ======================================
// DELETE /api/trips/:tripCode (Protected – admin)
// ======================================
const tripsDeleteTrip = async (req, res) => {
  try {
    const code = String(req.params.tripCode || '').trim().toUpperCase();
    const trip = await Trip.findOneAndDelete({ code }).exec();

    if (!trip) return res.status(404).json({ message: 'Trip not found' });
    return res.status(204).send();
  } catch (err) {
    return res.status(500).json({ message: 'Error deleting trip', error: err.message });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};
