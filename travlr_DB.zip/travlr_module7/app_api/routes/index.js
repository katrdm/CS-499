const express = require('express');
const router = express.Router();

const ctrlTrips = require('../controllers/trips');
const { requireAuth, requireAdmin } = require('../middleware/auth');

/*
 * =========================
 * AUTH ROUTES
 * =========================
 * POST /api/auth/login
 */
router.use('/auth', require('./auth'));

/*
 * =========================
 * TRIPS ROUTES
 * =========================
 */

// Public (no auth)
router
  .route('/trips')
  .get(ctrlTrips.tripsList);

router
  .route('/trips/:tripCode')
  .get(ctrlTrips.tripsFindByCode);

// Protected (admin only)
router
  .route('/trips')
  .post(requireAuth, requireAdmin, ctrlTrips.tripsAddTrip);

router
  .route('/trips/:tripCode')
  .put(requireAuth, requireAdmin, ctrlTrips.tripsUpdateTrip)
  .delete(requireAuth, requireAdmin, ctrlTrips.tripsDeleteTrip);

module.exports = router;
