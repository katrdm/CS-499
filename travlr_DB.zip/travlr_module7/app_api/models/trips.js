const mongoose = require('mongoose');

// Database validation and integrity rules
const tripSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true, trim: true, uppercase: true },
  name: { type: String, required: true, trim: true },
  resort: { type: String, required: true, trim: true },
  length: { type: Number, default: 0, min: 0 },       // days
  start: { type: Date, default: Date.now },           // start date
  price: { type: Number, default: 0, min: 0 },        // per person
  currency: { type: String, default: 'USD', uppercase: true, trim: true, minlength: 3, maxlength: 3 },
  description: { type: String, default: '', trim: true },
  image: { type: String, default: '', trim: true }
}, { timestamps: true });

// Collection name will be 'trips'
mongoose.model('trips', tripSchema);
