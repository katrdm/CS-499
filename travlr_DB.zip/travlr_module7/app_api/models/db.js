const mongoose = require('mongoose');

const dbURI = 'mongodb://127.0.0.1/travlr';

// Connect to MongoDB
mongoose.connect(dbURI);

// CONNECTION EVENTS
mongoose.connection.on('connected', () => {
  console.log(`MongoDB connected to ${dbURI}`);
});

mongoose.connection.on('error', err => {
  console.log('MongoDB connection error:', err);
});

mongoose.connection.on('disconnected', () => {
  console.log('MongoDB disconnected');
});

// CAPTURE APP TERMINATION
process.on('SIGINT', () => {
  mongoose.connection.close(() => {
    console.log('MongoDB disconnected through app termination');
    process.exit(0);
  });
});

// ===============================
// LOAD SCHEMAS (THIS IS THE FIX)
// ===============================
require('./trips');
require('./user');
