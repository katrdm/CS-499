require('dotenv').config();
require('./app_api/models/db');

const User = require('./app_api/models/user');

async function seed() {
  try {
    const username = 'admin';
    const password = 'password123';

    const existing = await User.findOne({ username });
    if (existing) {
      console.log('✅ Admin user already exists:', username);
      process.exit(0);
    }

    const user = new User({ username, role: 'admin' });
    user.setPassword(password);
    await user.save();

    console.log('✅ Admin user created');
    console.log('Username:', username);
    console.log('Password:', password);
    process.exit(0);
  } catch (err) {
    console.error('❌ Seed failed:', err);
    process.exit(1);
  }
}

seed();
