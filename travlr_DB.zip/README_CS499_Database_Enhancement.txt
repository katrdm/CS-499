Travlr Getaways Backend
CS 499 – Milestone Four: Enhancement Three (Databases)

What changed for the database enhancement:
- Stronger schema validation on Trip model (required fields, min constraints, normalized formats, timestamps)
- Data integrity improvements (unique constraint on trip code + explicit duplicate handling)
- Input sanitization / whitelisting (prevents mass assignment; trims/normalizes values before DB writes)
- Role-based access control (RBAC): added user.role (user/admin), JWT includes role, and admin-only middleware protects write routes
- Query refinement: lean queries and field selection for more efficient retrieval

How to run (typical):
1) npm install
2) Ensure MongoDB is running locally (default connection used in app_api/models/db.js)
3) Start the server (per your project scripts)
4) (Optional) Run seedAdmin.js to create an admin user, then login to obtain a JWT.

Author: Katerine Dubon
