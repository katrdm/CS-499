package com.example.weighttracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

public class WeightAdapter extends ListAdapter<WeightEntry, WeightAdapter.VH> {

    public interface Listener {
        void onEdit(WeightEntry entry);
        void onDelete(WeightEntry entry);
    }

    private final Listener listener;

    public WeightAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    static final DiffUtil.ItemCallback<WeightEntry> DIFF_CALLBACK =
            new DiffUtil.ItemCallback<WeightEntry>() {
                @Override
                public boolean areItemsTheSame(@NonNull WeightEntry oldItem, @NonNull WeightEntry newItem) {
                    return oldItem.id == newItem.id;
                }

                @Override
                public boolean areContentsTheSame(@NonNull WeightEntry oldItem, @NonNull WeightEntry newItem) {
                    return oldItem.date.equals(newItem.date) && oldItem.weight == newItem.weight;
                }
            };

    static class VH extends RecyclerView.ViewHolder {
        TextView txtDate, txtWeight;
        MaterialButton btnEdit, btnDelete;

        VH(@NonNull View itemView) {
            super(itemView);
            txtDate = itemView.findViewById(R.id.txtDate);
            txtWeight = itemView.findViewById(R.id.txtWeight);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_entry, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        WeightEntry entry = getItem(position);
        holder.txtDate.setText(entry.date);
        holder.txtWeight.setText(String.valueOf(entry.weight));
        holder.btnEdit.setOnClickListener(v -> listener.onEdit(entry));
        holder.btnDelete.setOnClickListener(v -> listener.onDelete(entry));
    }
}
