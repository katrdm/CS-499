package com.example.weighttracker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private AppDatabase db;
    private WeightAdapter adapter;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = AppDatabase.getInstance(this);

        RecyclerView rv = findViewById(R.id.recyclerView);
        rv.setLayoutManager(new LinearLayoutManager(this));

        adapter = new WeightAdapter(new WeightAdapter.Listener() {
            @Override
            public void onEdit(WeightEntry entry) {
                showEntryDialog(entry);
            }

            @Override
            public void onDelete(WeightEntry entry) {
                deleteEntry(entry);
            }
        });

        rv.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fabAdd);
        fab.setOnClickListener(v -> showEntryDialog(null));

        loadAll();
    }

    private void loadAll() {
        io.execute(() -> {
            List<WeightEntry> list = db.weightEntryDao().getAll();
            runOnUiThread(() -> adapter.submitList(list));
        });
    }

    private void deleteEntry(WeightEntry entry) {
        io.execute(() -> {
            db.weightEntryDao().delete(entry);
            List<WeightEntry> list = db.weightEntryDao().getAll();
            runOnUiThread(() -> adapter.submitList(list));
        });
    }

    private void showEntryDialog(WeightEntry existing) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_entry, null, false);
        TextInputEditText edtDate = view.findViewById(R.id.edtDate);
        TextInputEditText edtWeight = view.findViewById(R.id.edtWeight);

        boolean isEdit = existing != null;
        if (isEdit) {
            edtDate.setText(existing.date);
            edtWeight.setText(String.valueOf(existing.weight));
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(isEdit ? "Update Entry" : "Add Entry")
                .setView(view)
                .setPositiveButton(isEdit ? "Update" : "Add", null)
                .setNegativeButton("Cancel", (d, w) -> d.dismiss())
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String date = edtDate.getText() == null ? "" : edtDate.getText().toString().trim();
            String weightStr = edtWeight.getText() == null ? "" : edtWeight.getText().toString().trim();

            if (!isValidDate(date)) return;

            Double weight = parseWeight(weightStr);
            if (weight == null) return;

            if (!isEdit) {
                addEntry(date, weight);
            } else {
                existing.date = date;
                existing.weight = weight;
                updateEntry(existing);
            }
            dialog.dismiss();
        }));

        dialog.show();
    }

    private void addEntry(String date, double weight) {
        io.execute(() -> {
            db.weightEntryDao().insert(new WeightEntry(date, weight));
            List<WeightEntry> list = db.weightEntryDao().getAll();
            runOnUiThread(() -> adapter.submitList(list));
        });
    }

    private void updateEntry(WeightEntry entry) {
        io.execute(() -> {
            db.weightEntryDao().update(entry);
            List<WeightEntry> list = db.weightEntryDao().getAll();
            runOnUiThread(() -> adapter.submitList(list));
        });
    }

    private boolean isValidDate(String date) {
        if (date == null || date.length() != 10) return false;
        if (date.charAt(4) != '-' || date.charAt(7) != '-') return false;
        for (int i = 0; i < date.length(); i++) {
            if (i == 4 || i == 7) continue;
            if (!Character.isDigit(date.charAt(i))) return false;
        }
        return true;
    }

    private Double parseWeight(String s) {
        try {
            double w = Double.parseDouble(s);
            if (w <= 0 || w > 1500) return null;
            return w;
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
