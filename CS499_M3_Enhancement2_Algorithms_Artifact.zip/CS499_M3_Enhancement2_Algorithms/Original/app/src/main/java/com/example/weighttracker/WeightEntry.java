package com.example.weighttracker;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "weight_entries")
public class WeightEntry {
    @PrimaryKey(autoGenerate = true)
    public long id;

    public String date;   // YYYY-MM-DD
    public double weight; // e.g., 150.2

    public WeightEntry(String date, double weight) {
        this.date = date;
        this.weight = weight;
    }
}
