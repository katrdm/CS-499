package com.example.weighttracker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private AppDatabase db;
    private WeightAdapter adapter;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = AppDatabase.getInstance(this);

        RecyclerView rv = findViewById(R.id.recyclerView);
        rv.setLayoutManager(new LinearLayoutManager(this));

        adapter = new WeightAdapter(new WeightAdapter.Listener() {
            @Override
            public void onEdit(WeightEntry entry) {
                showEntryDialog(entry);
            }

            @Override
            public void onDelete(WeightEntry entry) {
                deleteEntry(entry);
            }
        });

        rv.setAdapter(adapter);

        searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                search(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText == null || newText.trim().isEmpty()) {
                    loadAll();
                } else {
                    search(newText);
                }
                return true;
            }
        });

        findViewById(R.id.btnSortDate).setOnClickListener(v -> sortByDate());
        findViewById(R.id.btnSortWeight).setOnClickListener(v -> sortByWeight());

        FloatingActionButton fab = findViewById(R.id.fabAdd);
        fab.setOnClickListener(v -> showEntryDialog(null));

        loadAll();
    }

    private void loadAll() {
        io.execute(() -> {
            List<WeightEntry> list = db.weightEntryDao().getAll();
            runOnUiThread(() -> adapter.submitList(list));
        });
    }

    private void search(String query) {
        io.execute(() -> {
            List<WeightEntry> results = db.weightEntryDao().searchByDate(query.trim());
            runOnUiThread(() -> adapter.submitList(results));
        });
    }

    private void sortByDate() {
        io.execute(() -> {
            List<WeightEntry> sorted = db.weightEntryDao().sortByDateAsc();
            runOnUiThread(() -> adapter.submitList(sorted));
        });
    }

    private void sortByWeight() {
        io.execute(() -> {
            List<WeightEntry> sorted = db.weightEntryDao().sortByWeightAsc();
            runOnUiThread(() -> adapter.submitList(sorted));
        });
    }

    private void deleteEntry(WeightEntry entry) {
        io.execute(() -> {
            db.weightEntryDao().delete(entry);
            List<WeightEntry> list = db.weightEntryDao().getAll();
            runOnUiThread(() -> adapter.submitList(list));
        });
    }

    private void showEntryDialog(WeightEntry existing) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_entry, null, false);
        TextInputEditText edtDate = view.findViewById(R.id.edtDate);
        TextInputEditText edtWeight = view.findViewById(R.id.edtWeight);

        boolean isEdit = existing != null;
        if (isEdit) {
            edtDate.setText(existing.date);
            edtWeight.setText(String.valueOf(existing.weight));
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(isEdit ? getString(R.string.update_entry) : getString(R.string.add_entry))
                .setView(view)
                .setPositiveButton(isEdit ? "Update" : "Add", null)
                .setNegativeButton("Cancel", (d, w) -> d.dismiss())
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String date = edtDate.getText() == null ? "" : edtDate.getText().toString().trim();
            String weightStr = edtWeight.getText() == null ? "" : edtWeight.getText().toString().trim();

            if (!isValidDate(date)) {
                toast("Invalid date. Use YYYY-MM-DD.");
                return;
            }

            Double weight = parseWeight(weightStr);
            if (weight == null) return;

            if (!isEdit) {
                addEntry(date, weight);
            } else {
                updateEntry(existing, date, weight);
            }
            dialog.dismiss();
        }));

        dialog.show();
    }

    private void addEntry(String date, double weight) {
        io.execute(() -> {
            int dup = db.weightEntryDao().countDuplicates(date, weight);
            if (dup > 0) {
                runOnUiThread(() -> toast("Duplicate prevented: same date and weight already exists."));
                return;
            }
            db.weightEntryDao().insert(new WeightEntry(date, weight));
            List<WeightEntry> list = db.weightEntryDao().getAll();
            runOnUiThread(() -> adapter.submitList(list));
        });
    }

    private void updateEntry(WeightEntry existing, String newDate, double newWeight) {
        io.execute(() -> {
            // If the values changed, prevent updating into a duplicate date+weight pair
            boolean changed = !existing.date.equals(newDate) || existing.weight != newWeight;
            if (changed) {
                int dup = db.weightEntryDao().countDuplicates(newDate, newWeight);
                if (dup > 0) {
                    runOnUiThread(() -> toast("Update blocked: duplicate date+weight exists."));
                    return;
                }
            }

            // Optimized update: update only this record (no rebuild of data structures)
            existing.date = newDate;
            existing.weight = newWeight;
            db.weightEntryDao().update(existing);

            List<WeightEntry> list = db.weightEntryDao().getAll();
            runOnUiThread(() -> adapter.submitList(list));
        });
    }

    private boolean isValidDate(String date) {
        if (date == null || date.length() != 10) return false;
        if (date.charAt(4) != '-' || date.charAt(7) != '-') return false;
        for (int i = 0; i < date.length(); i++) {
            if (i == 4 || i == 7) continue;
            if (!Character.isDigit(date.charAt(i))) return false;
        }
        return true;
    }

    private Double parseWeight(String s) {
        try {
            double w = Double.parseDouble(s);
            if (w <= 0 || w > 1500) {
                runOnUiThread(() -> toast("Weight out of range."));
                return null;
            }
            return w;
        } catch (NumberFormatException e) {
            runOnUiThread(() -> toast("Invalid weight."));
            return null;
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
