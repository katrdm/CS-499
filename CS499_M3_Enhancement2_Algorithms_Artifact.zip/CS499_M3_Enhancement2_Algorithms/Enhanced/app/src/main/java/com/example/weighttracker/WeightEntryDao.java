package com.example.weighttracker;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface WeightEntryDao {

    @Insert
    long insert(WeightEntry entry);

    @Update
    int update(WeightEntry entry);

    @Delete
    int delete(WeightEntry entry);

    @Query("SELECT * FROM weight_entries ORDER BY id DESC")
    List<WeightEntry> getAll();

    // Duplicate prevention: same date + same weight
    @Query("SELECT COUNT(*) FROM weight_entries WHERE date = :date AND weight = :weight")
    int countDuplicates(String date, double weight);

    // Search by date (partial match)
    @Query("SELECT * FROM weight_entries WHERE date LIKE '%' || :query || '%' ORDER BY id DESC")
    List<WeightEntry> searchByDate(String query);

    @Query("SELECT * FROM weight_entries ORDER BY date ASC")
    List<WeightEntry> sortByDateAsc();

    @Query("SELECT * FROM weight_entries ORDER BY weight ASC")
    List<WeightEntry> sortByWeightAsc();
}
