CS 499 - Milestone Three (Enhancement Two: Algorithms & Data Structures)

This artifact contains TWO Android Studio projects:

1) Original/
   - Baseline weight tracker (add/list/edit/delete) using Room + RecyclerView
   - No search, sort, or duplicate prevention logic

2) Enhanced/
   - Adds: search by date, sorting (date/weight), duplicate prevention (date+weight),
     and optimized updates (updates only the changed record + ListAdapter DiffUtil)

How to open:
- In Android Studio: File > Open > select either the Original or Enhanced folder.
- Let Gradle sync.
- Run on an emulator or a connected device.

Notes:
- Date format validation uses YYYY-MM-DD.
- Duplicate prevention rule is: SAME date AND SAME weight is blocked.
